package com.capgemini.bean;

import java.util.Scanner;

public class Question6A {
	private String firstName;
	private String lastName;

	public Question6A(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public void method() throws ExcClass {
		if (firstName.equals("") && lastName.equals("")) {
			throw new ExcClass("name is not correct", "lastName is not correct");
		} else
			System.out.println("full name is correct");
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name");
		String str = sc.nextLine();
		String str2 = sc.nextLine();
		Question6A obj = new Question6A(str, str2);

		try {
			obj.method();
		} catch (ExcClass e) {
			System.out.println(e);
			System.out.println(e.getMessage());
		}

	}

}
