package com.capgemini.bean;

public class ExcClass extends Exception {

	String firstName;
	String lastName;

	public ExcClass(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "nameException [FirstName=" + firstName + ", lastName=" + lastName + "]";
	}
}
