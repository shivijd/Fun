package com.cap.program5.bean;

public class Question3E {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Warranty obj = new Warranty();
		obj.m1();

	}

}
