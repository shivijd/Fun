package com.cap.program2.bean;

public class Main {

	public static void main(String[] args) {
		PositiveNumberCheck obj= new PositiveNumberCheck();
		String str="abcd";
		String temp=obj.inputString(str);
		if(temp.equals(str))
		{
			System.out.println("Positive");
		}
		else 
			System.out.println("Negative");
	}

}
