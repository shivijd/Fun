package com.cap.program2.bean;

import java.util.Arrays;

public class PositiveNumberCheck {
	public String inputString(String str) {
		char arr[] = str.toCharArray();
		Arrays.sort(arr);
		return new String(arr);
	}
}
