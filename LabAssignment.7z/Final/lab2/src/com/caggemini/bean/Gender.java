package com.caggemini.bean;

public enum Gender 
{
	M, F;

}
