package com.caggemini.bean;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person=new Person("Divya", "Bharathi",Gender.F, "12345");
		System.out.println("First name is " + person.getFirstName());
		System.out.println("Last name is " + person.getLastName());
		System.out.println("Gender is " + person.getGender());
		System.out.println("Num is " + person.getMobileNo());
	}

}
