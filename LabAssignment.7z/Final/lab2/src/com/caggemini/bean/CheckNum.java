package com.caggemini.bean;

public class CheckNum {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int number;
		number = Integer.parseInt(args[0]);
		if (number > 0) {
			System.out.println("Positive");
		} else if (number < 0) {
			System.out.println("Negative");
		} else {
			System.out.println("Zero");
		}
	}

}
