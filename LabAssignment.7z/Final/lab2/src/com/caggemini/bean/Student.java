package com.caggemini.bean;

public class Student {
	
	private int StudRollNo;
	private String StudName;
	private float StudMarks;
	public int getStudRollNo() {
		return StudRollNo;
	}
	public void setStudRollNo(int studRollNo) {
		StudRollNo = studRollNo;
	}
	public String getStudName() {
		return StudName;
	}
	public void setStudName(String studName) {
		StudName = studName;
	}
	public float getStudMarks() {
		return StudMarks;
	}
	public void setStudMarks(float studMarks) {
		StudMarks = studMarks;
	}
	
	@Override
	public String toString()
	{
		return "Student[Name: "+StudName+"StudRollNo"+StudRollNo+"StudMarks"+StudMarks+"]";
	}
	

	}


