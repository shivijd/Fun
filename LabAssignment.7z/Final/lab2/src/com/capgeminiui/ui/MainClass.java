package com.capgeminiui.ui;

import com.caggemini.bean.Student;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student student= new Student();
		/*s.setStudName("Vansh Arora");
		s.setStudMarks(90);
		s.setStudRollNo(151500598);
		
		System.out.println("Name is:" +  s.getStudName());
		System.out.println("Roll num is:" + s.getStudRollNo());
		System.out.println("Marks are:" +  s.getStudMarks()); */
	System.out.println(student);
		
	}

}
