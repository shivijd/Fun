package com.capgemini.bean;

import com.capgemini.ui.Account;

public class Current extends Account{
	int overdraft=500;
	public void withdraw(double amount)
	{
		if(super.balance-amount>overdraft)
		{
			System.out.println("True");
		}
		else
		{
			System.out.println("False");
		}
	}

}
