package com.capgemini.bean;

import com.capgemini.ui.Account;

public class Saving extends Account {
	final int minbal = 500;

	public void withdraw(double amount) {
		if (super.balance - amount > minbal) {
			System.out.println("Withdra Possible");
		} else {
			System.out.println("Withdraw not possible");
		}
	}

}
