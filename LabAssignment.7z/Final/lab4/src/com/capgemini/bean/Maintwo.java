package com.capgemini.bean;

import com.capgemini.ui.Account;

public class Maintwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account account1 = new Account();
		Account account2 = new Account();

		// Setting details
		account1.setBalance(2000);
		account1.setAccHolder("Suraj");
		account1.deposit(1000);
		account2.setBalance(1500);
		account2.setAccHolder("Rahul");
		account2.withdraw(1000);

		// Getting details inside print method
		System.out.println("Account holder is: " + account1.getAccHolder());
		System.out.println("Updated details: " + account1.getBalance());
		System.out.println("--------------------------------------");
		System.out.println("Account holder is: " + account2.getAccHolder());
		System.out.println("Updated details : " + account2.getBalance());
		System.out.println("--------------------------------------");
		System.out.println(account1);
		System.out.println(account2);

		// Creating object of Save Class
		Saving save = new Saving();

		// Creating object of Current Class
		Current current = new Current();

		save.withdraw(0);
		current.withdraw(0);
	}

}
