package com.capgemini.ui;


import com.capgemini.ui.Account;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account a1=new Account();
		Account a2=new Account();
		a1.setBalance(2000);
		a1.setAccHolder("Suraj");
		a1.deposit(2000);
		a2.setBalance(3000);
		a2.setAccHolder("Rahul");
		a2.withdraw(2000);
		
		System.out.println("Account holder is: " +a1.getAccHolder());
		System.out.println("Updated details: " +a1.getBalance());
		System.out.println("--------------------------------------");
		System.out.println("Account holder is: " +a2.getAccHolder());
		System.out.println("Updated details : " +a2.getBalance());
		System.out.println("--------------------------------------");
		System.out.println(a1);
		System.out.println(a2);
		
	
		

	}

}
